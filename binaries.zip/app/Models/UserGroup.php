<?php

namespace App\Models;

use Sofa\Eloquence\Eloquence;
use Sofa\Eloquence\Mappable;
use Sofa\Eloquence\Metable\InvalidMutatorException;

/**
 * Class UserGroup
 * @package App\Models
 */
class UserGroup extends ChocolateyModel
{
    use Eloquence, Mappable;

    /**
     * Disable Timestamps
     *
     * @var bool
     */
    public $timestamps = false;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'guilds';

    /**
     * Primary Key of the Table
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * The attributes that will be mapped
     *
     * @var array
     */
    protected $maps = [
        'badgeCode' => 'badge',
        'roomId' => 'room_id',
        'primaryColour' => 'color_one',
        'secondaryColour' => 'color_two'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'user_id',
        'badge',
        'slot_id',
        'id',
        'user_id',
        'room_id',
        'state',
        'rights',
        'forum',
        'date_created',
        'read_forum',
        'post_messages',
        'post_threads',
        'mod_forum'
    ];

    /**
     * The Appender(s) of the Model
     *
     * @var array
     */
    protected $appends = [
        'badgeCode',
        'roomId',
        'primaryColour',
        'secondaryColour',
        'type',
        'isAdmin'
    ];

    /**
     * Store Function
     *
     * A Group can't be inserted by the CMS.
     * Only by the Emulator
     */
    public function store()
    {
        throw new InvalidMutatorException("You cannot store an User Group by Chocolatey. Groups need be created from the Server.");
    }

    /**
     * Return if is Admin
     *
     * @TODO: Link with User Data
     *
     * @return bool
     */
    public function getIsAdminAttribute(): bool
    {
        return false;
    }

    /**
     * Get the Group Type
     *
     * @TODO: What NORMAL means?
     *
     * @return string
     */
    public function getTypeAttribute(): string
    {
        return 'NORMAL';
    }
}
