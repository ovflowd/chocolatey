<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class AzureModel
 * @package App\Models
 */
abstract class ChocolateyModel extends Model
{

}
