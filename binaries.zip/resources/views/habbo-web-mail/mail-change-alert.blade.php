<table align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border-collapse:collapse">
    <tbody>
    <tr>
        <td class="m_5540581390057463289container"
            style="color:#000000;font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;border-collapse:collapse;padding:0 10px 0 10px">
            <table align="center" border="0" cellpadding="0" cellspacing="0"
                   style="border-collapse:collapse;width:100%">
                <tbody>
                <tr>
                    <td align="left"
                        style="color:#000000;font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;border-collapse:collapse;padding:10px 0 0 0">
                        <img src="http://imgur.com/HAs98Uo.png"
                             alt="Habbo" height="40" width="110" class="CToWUd">
                    </td>
                </tr>
                </tbody>
            </table>
            <table align="center" border="0" cellpadding="0" cellspacing="0"
                   style="border-collapse:collapse;width:100%">
                <tbody>
                <tr>
                    <td align="left"
                        style="color:#000000;font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;border-collapse:collapse;padding:32px 0 24px 0">
                        <h1
                            style="font-family:'Ubuntu Condensed','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;font-size:24px;font-weight:normal;line-height:1;margin:0;padding:0 0 24px 0">
                            Hey there {{$name}}!</h1>
                        <p style="color:#000000;font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;font-size:16px;line-height:1.4;padding:0;margin:0 0 16px 0">
                            A yellow ducky told us that you requested to change your email address of the {{$chocolatey['name']}} account
                            to the email address: {{$newMail}}
                        <p style="color:#000000;font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;font-size:16px;line-height:1.4;margin:16px 0 16px 0;padding:0">
                            If you requested this change, you can disregard this email.</p>
                        <p style="color:#000000;font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;font-size:16px;line-height:1.4;margin:16px 0 16px 0;padding:0">
                            If you did not request this change, we recommend that you contact us as soon as
                            possible.</p>
                        <p style="color:#000000;font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;font-size:16px;line-height:1.4;padding:0;margin:16px 0 0 0">
                            – {{$chocolatey['name']}} Staff</p>
                    </td>
                </tr>
                </tbody>
            </table>
            <table align="center" border="0" cellpadding="0" cellspacing="0"
                   style="border-collapse:collapse;width:100%">
                <tbody>
                <tr>
                    <td align="center"
                        style="font-family:'Ubuntu','Trebuchet MS','Lucida Grande','Lucida Sans Unicode','Lucida Sans',Tahoma,sans-serif;border-collapse:collapse;color:#818a91;border-top:1px solid #aaaaaa;font-size:10px;line-height:1.4;padding:10px">
                        © 2017 {{$chocolatey['name']}} by Chocolatey
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>