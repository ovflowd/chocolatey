<table width="98%" border="0" cellspacing="0" cellpadding="0">
    <tbody>
    <tr>
        <td align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="595">
                <tbody>
                <tr>
                    <td align="left" style="border-bottom:1px solid #aaaaaa" height="70" valign="middle">
                        <table border="0" cellpadding="0" cellspacing="0">
                            <tbody>
                            <tr>
                                <td>
                                    <img src="http://imgur.com/HAs98Uo.png"
                                         alt="Habbo" width="110" height="40" style="margin-left:12px;display:block"
                                         class="CToWUd">
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="left" style="border-bottom:1px dashed #aaaaaa" valign="middle">
                        <table style="margin-left:12px;margin-right:12px;padding:0 0 10px 0;width:100%" border="0"
                               cellpadding="0" cellspacing="0">
                            <tbody>
                            <tr>
                                <td valign="top">

                                    <p style="font-family:Verdana,Arial,sans-serif;font-size:20px;padding-top:15px">
                                        Thanks for the order: {{$purchaseId}}.<br><br>Product: {{$product->name}}
                                        <br>
                                        Price: {{$product->price}}
                                    </p>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="top" align="center">
                        <table style="font-family:Verdana,Arial,sans-serif;text-align:justify;font-size:11px;color:#aaaaaa;padding-top:10px;padding-right:10px;padding-left:10px;padding-bottom:10px;margin-top:0pt;margin-right:0pt;margin-left:0pt;margin-bottom:0pt"
                               border="0" cellpadding="0" cellspacing="0" width="595">
                            <tbody>
                            <tr>
                                <td style="height:8px"></td>
                            </tr>
                            <tr>
                                <td valign="top">
                                    © 2017 {{$chocolatey['name']}} by Chocolatey
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>