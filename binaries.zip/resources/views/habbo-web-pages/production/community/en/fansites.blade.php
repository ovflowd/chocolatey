<h1>Official fansites</h1>
<p><img src="https://habboo-a.akamaihd.net/c_images/Fansites/habbo_friends.png" alt="Fansites" class="align-right"></p>
<p>Our official fansites at the moment are (fanfare):</p>
<ul>
    <li><a href="http://habboquests.com/" target="_blank">http://habboquests.com/</a></li>
    <li><a href="http://www.Habbox.com" target="_blank">http://www.Habbox.com</a></li>
    <li><a href="http://www.habbotiles.net" target="_blank">http://www.habbotiles.net</a></li>
    <li><a href="http://flyhabbo.net" target="_blank">http://flyhabbo.net</a></li>
    <li><a href="http://www.hffm.co.uk" target="_blank">http://www.hffm.co.uk</a></li>
    <li><a href="http://www.habbcrazy.net" target="_blank">http://www.habbcrazy.net</a></li>
    <li><a href="http://www.ThisHabbo.com" target="_blank">http://www.ThisHabbo.com</a></li>
    <li><a href="http://www.puhekupla.com" target="_blank">http://www.puhekupla.com</a></li>
    <li><a href="http://www.madhabbo.com" target="_blank">http://www.madhabbo.com</a></li>
    <li><a href="http://www.habbobites.com" target="_blank">http://www.habbobites.com</a></li>
    <li><a href="http://www.habboholiday.net/v1" target="_blank">http://www.habboholiday.net/v1</a></li>
    <li><a href="http://en.habbo-happy.net" target="_blank">http://en.habbo-happy.net/</a></li>
</ul>
<p>Every once in a while, we look for new official fansites, and when that happens we will publish a notification
    ingame. Check out our <a target="_blank"
                             ng-href="@{{'https://help.habbo.com/entries/22405102-Habbo-Fansite-Policy' | zendeskRedirectUrl}}">fansite
        policy</a> if you have any questions!</p>
<p>Always remember to keep your {{$chocolatey['name']}} login details separate and private! Don&apos;t use them to
    register
    on any other
    sites.</p>