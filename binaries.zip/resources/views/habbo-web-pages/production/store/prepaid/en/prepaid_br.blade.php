<p>{{$chocolatey['name']}} codes bought on <a href="http://www.pcgamesupply.com/buygames/habbo-hotel-credits-game-card/" target="_blank">PCGameSupply</a>
    are valid in all Habbo hotels! You can buy one with a credit card or with PayPal. Once you have the code, come back
    to this page and enter the code in the voucher code field. (Remember to log in first.)</p>
<p><a href="http://www.pcgamesupply.com/buygames/habbo-hotel-credits-game-card/" class="remove-link"
      target="_blank"><img src="https://habboo-a.akamaihd.net/c_images/Prepaid/pcgamesupply_logo_161x60.png"
                           alt="PCGameSupply"></a></p>
