<h4>Something the matter?</h4>
<p>If you didn&apos;t receive your earned credits even though you followed the instructions, please contact the offer
    provider by clicking &apos;My {{$chocolatey['name']}} Credits&apos; at the top right corner of the list of
    offers.</p>
<p>If you&apos;re having other trouble with purchases in the {{$chocolatey['name']}}Mall, please see our
    <a target="_blank" ng-href="@{{'https://help.habbo.com/' | zendeskRedirectUrl}}">Help
        pages</a>.
</p>
