<h3> {{$chocolatey['name']}} Way</h3>
<p>Follow the <a href="/playing-habbo/habbo-way"> {{$chocolatey['name']}} Way</a> - a series of guidelines to keep you
    on
    the right side of fun!</p>