<h3>Need help?</h3>
<p>Learn how to help yourself or how to get a moderator&apos;s help on our <a href="/playing-habbo/help">Help page</a>.
    It also contains a list of phone numbers and websites if you need someone to talk to.</p>
<p>If you can&apos;t find answers there, please see our <a target="_blank"
                                                           ng-href="@{{'https://help.habbo.com/' | zendeskRedirectUrl}}">Customer
        Support &amp; Helpdesk</a> pages.</p>