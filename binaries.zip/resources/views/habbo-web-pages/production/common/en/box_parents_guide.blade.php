<h3>Parents&apos; guide</h3>
<p>Curious about the effective tools that ensure our users can have fun in a safe environment? See our <a
            target="_blank"
            ng-href="@{{'https://help.habbo.com/forums/144065-information-for-parents' | zendeskRedirectUrl}}">Parents&apos;
        Guide on the Customer Support &amp; Helpdesk</a> pages.</p>