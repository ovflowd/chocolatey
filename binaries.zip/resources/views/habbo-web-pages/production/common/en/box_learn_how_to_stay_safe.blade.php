<h3>Safety tips</h3>
<p>Protect yourself with awareness! Learn how to <a href="/playing-habbo/safety">stay safe on the internet</a>.</p>