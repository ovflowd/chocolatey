<h3>Account issues</h3>
<p>Got a query about your {{$chocolatey['name']}} account, a purchase or a feature? Find your answer at the <a target="_blank"
                                                                                             ng-href="@{{'https://help.habbo.com' | zendeskRedirectUrl}}">{{$chocolatey['name']}}
        Helpdesk</a>.</p>
