<h3>How to Play</h3>
<p>Get creative, get constructive, get social! See our <a href="/playing-habbo/how-to-play">tips on what to do
        in {{$chocolatey['name']}} </a>.</p>